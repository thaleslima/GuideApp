

/**
 * @ngdoc function
 * @name guideAppApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the guideAppApp
 */
angular.module('guideAppApp')
    .controller('AboutCtrl', function () {
        'use strict';
    
        this.awesomeThings = [
            'HTML5 Boilerplate',
            'AngularJS',
            'Karma'
        ];
    });
